import java.sql.SQLOutput;

public class Main {
    static void main() {
        //CREAMOS PELICULAS Y LAS METEMOS EN UN ARRAY(MAXIMO 5)
        Pelicula peli1 = new Pelicula("El Rey León", "Roger Allers", 88, 15, 7.0);
        Pelicula peli2 = new Pelicula("El Origen", "Christopher Nolan", 148, 13, 7.0);
        Pelicula peli3 = new Pelicula("Coco", "Adrian Molina", 105, 7, 7.0);
        Pelicula peli4 = new Pelicula("Joker", "Todd Phillips", 122, 16, 7.0);
        Pelicula peli5 = new Pelicula("Interestellar", "Crhistopher Nolan", 169, 12, 7.0);


        Pelicula [] pelis1 = new Pelicula[5];
        pelis1[0] = peli1;
        pelis1[1] = peli2;
        pelis1[2] = peli3;
        pelis1[3] = peli4;
        pelis1[4] = peli5;

        //Para crear un cine necesita saber las peliculas que hay en el
        Cine cine = new Cine();
        cine.aniadirPeli(peli1);
        cine.aniadirPeli(peli2);
        cine.aniadirPeli(peli3);
        cine.aniadirPeli(peli4);
        cine.aniadirPeli(peli5);


        //Cada sala necesita una pelicula para reproducir
        Sala sala1 = new Sala(peli1);
        Sala sala2 = new Sala(peli2);
        Sala sala3 = new Sala(peli3);



        System.out.println("----------------------SALA 1----------------------");
        sala1.mostrarSala();
        //Creo espectadores y los meto en un array
        Espectador [] espectadores1 = new Espectador[30];
        int i = 0;
        for (Nombres nombre: Nombres.values()) {
            int edad = (int) ((Math.random() * (101)));
            int dinero = (int) ((Math.random() * 100));

            Espectador esp1 = new Espectador(nombre.toString(), edad, dinero);
            espectadores1[i] = esp1;
            i++;
        }
        //Le doy la lista de espectadores y los esparce segun los criterios por la sala
        sala1.spreadEspectadores(espectadores1);
        System.out.println();
        System.out.println();
        System.out.println("------------------SALA CON ESPECTADORES------------------");

        sala1.mostrarSala();




        System.out.println("----------------------SALA 2----------------------");
        sala2.mostrarSala();
        //Creo espectadores y los meto en un array
        Espectador [] espectadores2 = new Espectador[30];
        i = 0;
        for (Nombres nombre: Nombres.values()) {
            int edad = (int) ((Math.random() * (101)));
            int dinero = (int) ((Math.random() * 20));

            Espectador esp1 = new Espectador(nombre.toString(), edad, dinero);
            espectadores2[i] = esp1;
            i++;
        }
        //Le doy la lista de espectadores y los esparce segun los criterios por la sala
        sala2.spreadEspectadores(espectadores2);
        System.out.println();
        System.out.println();
        System.out.println("------------------SALA CON ESPECTADORES------------------");
        sala2.mostrarSala();



        System.out.println("----------------------SALA 3----------------------");
        sala3.mostrarSala();

        //Creo espectadores y los meto en un array
        Espectador [] espectadores3 = new Espectador[30];
        i = 0;
        for (Nombres nombre: Nombres.values()) {
            int edad = (int) ((Math.random() * (101)));
            int dinero = (int) ((Math.random() * 20));

            Espectador esp1 = new Espectador(nombre.toString(), edad, dinero);
            espectadores3[i] = esp1;
            i++;
        }

        //Le doy la lista de espectadores y los esparce segun los criterios por la sala
        sala3.spreadEspectadores(espectadores3);
        System.out.println();
        System.out.println();
        System.out.println("------------------SALA CON ESPECTADORES------------------");

        sala3.mostrarSala();
    }
}
